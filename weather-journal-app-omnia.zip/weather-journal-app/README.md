# Weather-Journal App Project

## Overview
This app is used to get weather temp and conditions in UI FOR ZIPcode provided

## UI(user Interface)
contains 
- zipcode input field
- user feeling 
- generate button
- location & date & weather condition
## Instructions
 `server.js` file : create server with express &cors &body-parser 
 `website/app.js` file : Asyncronus funcations used to get data from weather API to perform actions in response to requests from users
 and handling errors
## 